# Proyecto Minimarket
Este programa tiene como objetivo facilitar a una persona que busque organizar un negocio se le sea más fácil y practico a la hora de vender y ofrecer y saber cuánto stock se tiene de los diferentes productos.

## Caracteristicas del código

* Idea general: 
-Posee una base de datos , donde se almecenan la informacion de los clientes y productos en stock.
-Utiliza una estructura simple de switch y case, en donde el switch se encarga de ir navegando por el menú dependiendo el case que seleccione el cliente. 

* Estructura: 
titulo1()
menu1()
menu2()
menu3()
menu4()
mostrar_proveedores()
ventas()
clientes()
codigodelproducto()
productos()
inventario()
main()
---
* Funcionamiento:
 https://prnt.sc/QzqWyXsnMDDb

## Integrantes:
* Daniel Rojas Varela
* Cristian Valencia Azar